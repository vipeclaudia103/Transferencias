def validar_iban(iban):
    
    # Valida un IBAN (International Bank Account Number).

    # Parameters:
    #     iban (str): IBAN a validar.

    # Returns:
    #     bool: True si el IBAN es válido, False si no lo es.
    #     str: Mensaje de error si el IBAN no es válido.
    
    # Verificar longitud del IBAN
    if len(iban) != 34:
        if len(iban) < 34:
            return False, "El IBAN tiene menos de 34 caracteres."
        if len(iban) > 34:
            return False, "El IBAN tiene más de 34 caracteres."

    # Verificar caracteres alfanuméricos
    if not iban.isalnum():
        return False, "El IBAN no puede contener caracteres especiales."

    # Verificar si el IBAN está vacío
    if not iban:
        return False, "El IBAN no puede estar vacío."

    return True, ""


def validar_iban_unicidad(iban_origen, iban_destino):
    
    # Verifica si el IBAN de la cuenta de origen es diferente al IBAN de la cuenta de destino.

    # Parameters:
    #     iban_origen (str): IBAN de la cuenta de origen.
    #     iban_destino (str): IBAN de la cuenta de destino.

    # Returns:
    #     bool: True si los IBAN son diferentes, False si son iguales.
    #     str: Mensaje de error si los IBAN son iguales.
    
    if iban_origen == iban_destino:
        return False, "El IBAN de origen y destino es el mismo."

    return True, ""


def validar_transferencia(valor):
    
    # Valida la cantidad a transferir.

    # Parameters:
    #     valor (str): Cantidad a transferir.

    # Returns:
    #     bool: True si la cantidad es válida, False si no lo es.
    #     str: Mensaje de error si la cantidad no es válida.
    
    try:
        cantidad = int(valor)
    except ValueError:
        return False, "La cantidad debe ser un número entero."

    if cantidad < 0:
        return False, "La cantidad debe ser un número positivo."
    elif cantidad > 10000:
        return False, "El valor de la transferencia no puede ser mayor a 10000."

    return True, ""

