from django.urls import path
from . import views

urlpatterns = [
    path('', views.transferir_dinero, name='transferir_dinero'),
]
