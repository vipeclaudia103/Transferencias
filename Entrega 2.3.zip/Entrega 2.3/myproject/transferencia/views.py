from django.shortcuts import render
from .forms import TransferenciaForm
from .validador import validar_iban, validar_iban_unicidad, validar_transferencia

def transferir_dinero(request):
    mensaje = None
    if request.method == 'POST':
        form = TransferenciaForm(request.POST)
        if form.is_valid():
            origen = form.cleaned_data['origen']
            destino = form.cleaned_data['destino']
            cantidad = form.cleaned_data['cantidad']

            validacion_origen, mensaje_origen = validar_iban(origen)
            validacion_destino, mensaje_destino = validar_iban(destino)
            validacion_unicidad, mensaje_unicidad = validar_iban_unicidad(origen, destino)
            validacion_cantidad, mensaje_cantidad = validar_transferencia(cantidad)

            if validacion_origen and validacion_destino and validacion_unicidad and validacion_cantidad:
                # Realizar la transferencia
                mensaje = f"Transferencia realizada: Cuenta origen: {origen}, Cuenta destino: {destino}, Cantidad transferida: {cantidad} euros"
            else:
                errores = [mensaje_origen, mensaje_destino, mensaje_unicidad, mensaje_cantidad]
                mensaje = ' '.join(errores)
        else:
            mensaje = "Formulario no válido"
    else:
        form = TransferenciaForm()
    
    return render(request, 'transferencia/transferir.html', {'form': form, 'mensaje': mensaje})
