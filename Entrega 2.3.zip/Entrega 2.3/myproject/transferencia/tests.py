from django.test import TestCase
from transferencia.validador import (
    validar_iban,
    validar_iban_unicidad,
    validar_transferencia
)

class TestValidacion(TestCase):

    def test_validar_iban(self):
        # Longitud del 
        iban_valido = "ES34567890123456789012345678901234"
        iban_invalido_corto = "ES1234"
        iban_invalido_largo = "ES9121000418450200051332000000000000"

        self.assertTrue(validar_iban(iban_valido)[0])
        self.assertFalse(validar_iban(iban_invalido_corto)[0])
        self.assertFalse(validar_iban(iban_invalido_largo)[0])
        
        # Caracteres invalidos
        iban_invalido_caracteres = "ES9121000418450$00051332"    
        self.assertFalse(validar_iban(iban_invalido_caracteres)[0])  # Se espera que sea inválido

    def test_validar_iban_vacio(self):
        iban_vacio = ""
        self.assertFalse(validar_iban(iban_vacio)[0])  # Se espera que sea inválido

    def test_validar_iban_unicidad(self):
        iban_origen = "ES9121000418450200051332"
        iban_destino = "ES9121000418450200051332"

        self.assertFalse(validar_iban_unicidad(iban_origen, iban_destino)[0])  # Se espera que sea inválido

    def test_validar_transferencia_valor_negativo(self):
        resultado, mensaje = validar_transferencia("-100")
        self.assertFalse(resultado)
        self.assertEqual(mensaje, "La cantidad debe ser un número positivo.")

    def test_validar_transferencia_valor_no_entero(self):
        resultado, mensaje = validar_transferencia("abc")
        self.assertFalse(resultado)
        self.assertEqual(mensaje, "La cantidad debe ser un número entero.")

    def test_validar_transferencia_valor_mayor_a_10000(self):
        resultado, mensaje = validar_transferencia("15000")
        self.assertFalse(resultado)
        self.assertEqual(mensaje, "El valor de la transferencia no puede ser mayor a 10000.")

