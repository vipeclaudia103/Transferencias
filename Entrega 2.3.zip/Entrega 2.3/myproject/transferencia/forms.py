from django import forms

class TransferenciaForm(forms.Form):
    origen = forms.CharField(label='IBAN de la cuenta origen', max_length=34)
    destino = forms.CharField(label='IBAN de la cuenta destino', max_length=34)
    cantidad = forms.IntegerField(label='Cantidad a transferir')
