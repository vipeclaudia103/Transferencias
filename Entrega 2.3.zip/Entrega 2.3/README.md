# Entrega 2.3: Transferencia de Dinero

Asignatura: Arquitecturas de Software Distribuidas
Nombre: Claudia Viñals Perlado
Tiempo invertido: 4 horas

## Descripción

Este repositorio contiene un proyecto Django para realizar transferencias bancarias entre cuentas. El proyecto incluye un formulario para ingresar la información de la cuenta de origen, la cuenta de destino y la cantidad a transferir. También proporciona funcionalidades para realizar la transferencia o cancelarla.

## Requerimientos

Antes de ejecutar las pruebas automatizadas, asegúrate de tener instaladas todas las dependencias del proyecto. Puedes instalarlas utilizando el archivo `requirements.txt`. Si aún no lo has hecho, puedes instalar las dependencias ejecutando el siguiente comando en tu entorno virtual:

```bash
pip install -r requirements.txt
```

## Uso

1. Ejecuta el servidor de desarrollo:

```bash
python manage.py runserver
```

2. Abre tu navegador web y ve a la dirección http://127.0.0.1:8000/transferencia/

3. Rellena el formulario con los detalles de la transferencia: IBAN de origen, IBAN de destino y cantidad a transferir.

4. Haz clic en el botón "Transferir" para realizar la transferencia.

5. Si la transferencia es exitosa, verás un mensaje de confirmación. Si hay algún error, se mostrará un mensaje de error detallado.

## Ejecución de las Pruebas

Para ejecutar las pruebas unitarias, sigue estos pasos:

1. Asegúrate de tener Python instalado en tu sistema.
2. Abre una terminal o línea de comandos.
3. Navega hasta el directorio donde se encuentra el archivo `manage.py`.
4. Ejecuta el siguiente comando:

```bash
cd "Entrega 2.3\myproject"
python manage.py test
```

5. Observa la salida en la terminal para verificar si las pruebas pasaron correctamente o si se encontraron errores.

## Bibliografía

- Real Python: [Python Testing](https://realpython.com/python-testing/#writing-your-first-test)


